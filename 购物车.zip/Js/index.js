(function(){
    var oBanner=document.querySelector("div.obanner");
    var db=document.querySelector(".banner")
    var oListImg=document.querySelector(".obanner ul");
    console.log(oListImg);
    var oLi=oListImg.querySelectorAll("li");
    var oBtn=oBanner.querySelectorAll("#btns span");
    console.log(oBtn);
    var oBtns=document.getElementById("btns").getElementsByTagName("span");
    var oDots=oBanner.querySelectorAll("#dots>li");
    console.log(oDots);
    var index=1;
    var w=db.clientWidth;
    console.log(w);
    oBtns[0].onclick=leftToRight;
    oBtns[1].onclick=auto;
    var timer;
    var len=oLi.length;
    start();
    var oClr=oBanner.querySelectorAll(".clr>li");
    var sub=oBanner.querySelector("#block_regist>li>input#regist_submit_action");
    var sub2=oBanner.querySelector("#block_regist>li>input#input_invite_code");
    for(var i=0;i<oClr.length;i++){
        (function(i){
            oClr[i].onclick=function(){
                clrOn(i);
            }
        })(i);
    }
    function clrOn(i){
        for(var k=0;k<oClr.length;k++){ oClr[k].className=" ";}
        oClr[i].className="ck";
        var loginClr=oClr[i].id;
        getVerifyCode();
        if(loginClr=="west"){
            sub.value="志愿者注册";
            moveTime(sub,{width:110},200,function(){
                sub2.style.display="block";
            });
        }
        else if(loginClr=="hr"){
            sub.value="企业注册";
            moveTime(sub,{width:250},200);
            sub2.style.display="none";
        }else{
            sub.value="求职者注册";
            moveTime(sub,{width:110},200,function(){
                sub2.style.display="block";
            });
        }
    }
    for(var i=0;i<oDots.length;i++){
        (function(i){
            oDots[i].onclick=function(){
                index=i+1;
                moveTime(oListImg,{"left":-w*index});
                dotOn(i);//当前圆点添加样式
            }
        })(i);
    }
    oBanner.onmouseenter=function(){
        moveTime(oBtn[0],{"left":20},100);
        moveTime(oBtn[1],{"right":20},100);
        stop();
    }
    oBanner.onmouseleave=function(){
        moveTime(oBtn[0],{"left":-50},100);
        moveTime(oBtn[1],{"right":-50},100);
        start();
    }
    function start(){
        timer=setInterval(auto,4000);
    }
    function stop(){
        clearInterval(timer);
    }
    function dotOn(i){
        for(var k=0;k<oDots.length;k++){ oDots[k].className=" ";}
        oDots[i].className="on";
    }
    function leftToRight(){//左按钮
        index--;
        if(index<=0){
            dotOn(4);
            moveTime(oListImg,{"left":-w*index},function(){
                oListImg.style.left=-(len-2)*w+"px";
                index=len-2;
            })
        }else{
            moveTime(oListImg,{"left":-w*index});
            dotOn(index-1);
        }
    }
    function auto(){//右按钮
        index++;//0~6
        if(index<=len-2){
            dotOn(index-1);
            moveTime(oListImg,{"left":-w*index});//-w*index  
        }else{
            dotOn(0);
            moveTime(oListImg,{"left":-w*index},function(){
                oListImg.style.left=-w+"px";
                index=1;
            });
        }
    }
})();

function getCss(ele,attr){//获取ele元素的attr当前样式
    return ele.currentStyle?ele.currentStyle[attr]:getComputedStyle(ele,null)[attr];
}

function moveTime(obj,json,M,t,callback){
    var st=new Date().getTime();
    var start={};
    var target={};
    for(var attr in json){
        /*if(attr=="opacity"){
            start[attr]=parseInt(getCss(obj,attr)*100);
            target[attr]=target[attr]=json[attr]*100;
        }*/
        start[attr]=attr=="opacity"?parseInt(getCss(obj,attr)*100):parseInt(getCss(obj,attr));
        target[attr]=attr=="opacity"?target[attr]=json[attr]*100:target[attr]=json[attr];
    }
    switch(typeof M){
        case "undefined":
            M="linear";
            t=500;
        break;
        case "number":
            switch(typeof t){
                case "undefined":
                    t=M;
                    M="linear";
                break;
                case "string":
                    var ql=M;
                    M=t;
                    t=ql;
                break;
                case "function":
                    callback=t;
                    t=M;
                    M="linear";
                break;
            }
        break;
        case "function":
            callback=M;
            M="linear";
            t=500;
        break;
        default:
            switch(typeof t){
                case "undefined":
                    t=500;
                break;
                case "function":
                    callback=t;
                    t=500;
                break;
            }
        break;
    }
    var id=setInterval(function(){
        var t1=new Date().getTime();
        if(t1-st<t){
            for(var attr in json){
                if(attr=="opacity"){
                    obj.style["filter"]="alpha(opacity="+Tween[M](t1-st,start[attr],target[attr]-start[attr],t)+")";
                    obj.style["opacity"]=Tween[M](t1-st,start[attr],target[attr]-start[attr],t)/100;
                }else{
                    obj.style[attr]=Tween[M](t1-st,start[attr],target[attr]-start[attr],t)+"px";
                }
            }
        }else{
            clearInterval(id);
            for(var attr in json){
                if(attr=="opacity"){
                    obj.style["opacity"]=(target[attr])/100;
                    obj.style["filter"]="alpha(opacity)"+(target[attr])+")"
                }
                obj.style[attr]=target[attr]+"px";
            }
            callback&&callback.call(obj);
        }
    },13);
}

var Tween = {
    linear: function (t, b, c, d){  //匀速
        return c*t/d + b;   //  t/d = prop;
    },
    easeIn: function(t, b, c, d){  //加速曲线
        return c*(t/=d)*t + b;
    },
    easeOut: function(t, b, c, d){  //减速曲线
        return -c *(t/=d)*(t-2) + b;
    },
    easeBoth: function(t, b, c, d){  //加速减速曲线
        if ((t/=d/2) < 1) {
            return c/2*t*t + b;
        }
        return -c/2 * ((--t)*(t-2) - 1) + b;
    },
    easeInStrong: function(t, b, c, d){  //加加速曲线
        return c*(t/=d)*t*t*t + b;
    },
    easeOutStrong: function(t, b, c, d){  //减减速曲线
        return -c * ((t=t/d-1)*t*t*t - 1) + b;
    },
    easeBothStrong: function(t, b, c, d){  //加加速减减速曲线
        if ((t/=d/2) < 1) {
            return c/2*t*t*t*t + b;
        }
        return -c/2 * ((t-=2)*t*t*t - 2) + b;
    },
    elasticIn: function(t, b, c, d, a, p){  //正弦衰减曲线（弹动渐入）
        if (t === 0) {
            return b;
        }
        if ( (t /= d) === 1 ) {
            return b+c;
        }
        if (!p) {
            p=d*0.3;
        }
        if (!a || a < Math.abs(c)) {
            a = c;
            var s = p/4;
        } else {
            var s = p/(2*Math.PI) * Math.asin (c/a);
        }
        return -(a*Math.pow(2,10*(t-=1)) * Math.sin( (t*d-s)*(2*Math.PI)/p )) + b;
    },
    elasticOut: function(t, b, c, d, a, p){    //正弦增强曲线（弹动渐出）
        if (t === 0) {
            return b;
        }
        if ( (t /= d) === 1 ) {
            return b+c;
        }
        if (!p) {
            p=d*0.3;
        }
        if (!a || a < Math.abs(c)) {
            a = c;
            var s = p / 4;
        } else {
            var s = p/(2*Math.PI) * Math.asin (c/a);
        }
        return a*Math.pow(2,-10*t) * Math.sin( (t*d-s)*(2*Math.PI)/p ) + c + b;
    },
    elasticBoth: function(t, b, c, d, a, p){
        if (t === 0) {
            return b;
        }
        if ( (t /= d/2) === 2 ) {
            return b+c;
        }
        if (!p) {
            p = d*(0.3*1.5);
        }
        if ( !a || a < Math.abs(c) ) {
            a = c;
            var s = p/4;
        }
        else {
            var s = p/(2*Math.PI) * Math.asin (c/a);
        }
        if (t < 1) {
            return - 0.5*(a*Math.pow(2,10*(t-=1)) *
                Math.sin( (t*d-s)*(2*Math.PI)/p )) + b;
        }
        return a*Math.pow(2,-10*(t-=1)) *
            Math.sin( (t*d-s)*(2*Math.PI)/p )*0.5 + c + b;
    },
    backIn: function(t, b, c, d, s){     //回退加速（回退渐入）
        if (typeof s === 'undefined') {
            s = 1.70158;
        }
        return c*(t/=d)*t*((s+1)*t - s) + b;
    },
    backOut: function(t, b, c, d, s){
        if (typeof s === 'undefined') {
            s = 3.70158;  //回缩的距离
        }
        return c*((t=t/d-1)*t*((s+1)*t + s) + 1) + b;
    },
    backBoth: function(t, b, c, d, s){
        if (typeof s === 'undefined') {
            s = 1.70158;
        }
        if ((t /= d/2 ) < 1) {
            return c/2*(t*t*(((s*=(1.525))+1)*t - s)) + b;
        }
        return c/2*((t-=2)*t*(((s*=(1.525))+1)*t + s) + 2) + b;
    },
    bounceIn: function(t, b, c, d){    //弹球减振（弹球渐出）
        return c - Tween['bounceOut'](d-t, 0, c, d) + b;
    },
    bounceOut: function(t, b, c, d){
        if ((t/=d) < (1/2.75)) {
            return c*(7.5625*t*t) + b;
        } else if (t < (2/2.75)) {
            return c*(7.5625*(t-=(1.5/2.75))*t + 0.75) + b;
        } else if (t < (2.5/2.75)) {
            return c*(7.5625*(t-=(2.25/2.75))*t + 0.9375) + b;
        }
        return c*(7.5625*(t-=(2.625/2.75))*t + 0.984375) + b;
    },
    bounceBoth: function(t, b, c, d){
        if (t < d/2) {
            return Tween['bounceIn'](t*2, 0, c, d) * 0.5 + b;
        }
        return Tween['bounceOut'](t*2-d, 0, c, d) * 0.5 + c*0.5 + b;
    }
}