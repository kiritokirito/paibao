-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: mysql.1473.cn:3306
-- Generation Time: 2022-03-26 18:07:46
-- 服务器版本： 5.7.22-0ubuntu0.16.04.1-log
-- PHP Version: 7.0.32-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `MySQL`
--

-- --------------------------------------------------------

--
-- 表的结构 `Collection`
--

CREATE TABLE `Collection` (
  `Image` varchar(500) NOT NULL,
  `Title` varchar(50) NOT NULL,
  `Price` varchar(10) NOT NULL,
  `Time` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `Collection`
--

INSERT INTO `Collection` (`Image`, `Title`, `Price`, `Time`) VALUES
('file:///C:/Users/zyq/Desktop/B%E6%8B%8D%E5%AE%9D/%E7%A5%9D%E9%9B%8D%E7%90%AA%E5%B0%8F%E7%BB%84/%E4%B8%AA%E4%BA%BA%E4%B8%AD%E5%BF%83/image/mi.png', 'Apple iPhone 13 Pro Max (A264455)  12 + 256GB 石墨色', '￥9799.00', '收藏时间: 2022-3-14'),
('file:///C:/Users/zyq/Desktop/B%E6%8B%8D%E5%AE%9D/%E7%A5%9D%E9%9B%8D%E7%90%AA%E5%B0%8F%E7%BB%84/%E4%B8%AA%E4%BA%BA%E4%B8%AD%E5%BF%83/image/mi.png', '小米MI 小米11 Pro 骁龙888 2K AMOLED四曲面柔性屏 67W无线闪充', '￥4799.00', '收藏时间: 2021-11-18'),
('file:///C:/Users/zyq/Desktop/B%E6%8B%8D%E5%AE%9D/%E7%A5%9D%E9%9B%8D%E7%90%AA%E5%B0%8F%E7%BB%84/%E4%B8%AA%E4%BA%BA%E4%B8%AD%E5%BF%83/image/mi.png', '荣耀Play5T Pro 6400万双摄 6.6英寸全视屏 22.5W超级快充 钛空银', '￥1099.00', '收藏时间: 2022-1-6');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Collection`
--
ALTER TABLE `Collection`
  ADD PRIMARY KEY (`Title`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
